$Id: README.win32.txt,v 1.2 2004/03/17 18:39:20 pcharles Exp $

                            jpcap win32 .dll README


  This file contains instructions for users who downloaded the .zip
  distribution for Windows.

  This distribution is not useful without:

    o The underlying libpcap library for Windows, known as winpcap. 
      Download the auto-installer from:

        http://winpcap.polito.it


  If you are planning on developing an application which uses jpcap, 
  then you might want to download the more complete .tar.gz distribution.

    http://sourceforge.net/project/showfiles.php?group_id=27207

  The .tar.gz distributoin contains more complete documentation and can be 
  used to build the dll included in this distribution.


  This win32 distribution is provided to help Windows users who don't have 
  the tools or skills to build the jpcap native library from source.

  Still, some familiarity with Java and Windows development is required to 
  get jpcap classes, libpcap for Windows, and the .dll included in this 
  distribution to work together.


  See the file README and other documents in the ./docs directory for more 
  information.


